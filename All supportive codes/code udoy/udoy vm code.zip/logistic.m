function x_out = logistic(delta_theta,delta0,phi)

    x_out = delta0-(2*delta0*phi.^2).*(1 - (delta_theta./delta0).^2);
    x_out(isnan(x_out))=0;
end
