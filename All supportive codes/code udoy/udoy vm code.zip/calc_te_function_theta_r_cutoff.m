
function [tr_en,td_corr]=calc_te_function_theta_r_cutoff(nbird,theta_out,TMAX,delete_inds_r,delete_inds_theta,r_array,theta_array,nsymbols,delay)

for j=1:nbird
    x=theta_out(j,1:TMAX);
    symbols(j,:)=uint8(get_symbol_strings(x,nsymbols));
end

for bird1=1:nbird
    for bird2=1:nbird
        
        k=1;
        l=1;
        d=delay;
        x = symbols(bird2,:);
        y=symbols(bird1,:);
        %probability of x,x,y%%
        
        vec_y = fliplr(sequence_prob(y,l));
        vec_x_x_1 = fliplr(sequence_prob(x,k+1));
        vec_x_x_y = [vec_x_x_1(d:end,:) vec_y(1:end-d,:)];
        
        [C,~,ic]=unique(vec_x_x_y,'rows');
        for r_ind=1:length(r_array)
            for theta_ind=1:length(theta_array)
                if (bird1~=bird2)
                    delete1 = find(delete_inds_r(1:TMAX-1,bird1,bird2) >= r_ind);
                    
                    delete2=find(delete_inds_theta(1:TMAX-1,bird1,bird2) >= theta_ind);
                    delete=union(delete1,delete2);
                    
                    tr_en{r_ind,theta_ind}(bird1,bird2)=probability_distribution_cutoff(symbols(bird2,:),symbols(bird1,:),nsymbols,delete,theta_out,C,ic,vec_x_x_y);
                    theta1=theta_out(bird1,1:end-1);
                    theta2=theta_out(bird2,2:end);
                    
                    theta1(delete)=[];
                    theta2(delete)=[];
                    if (~isempty(theta1) & ~isempty(theta2))
                        td_corr{r_ind,theta_ind}(bird1,bird2) = corr(theta1',theta2');
                    else
                        td_corr{r_ind,theta_ind}(bird1,bird2)=0;
                    end
                    %tdmi{r_ind}(bird1,bird2)=mutual_information_short_delete(symbols(bird1,1:end-1),symbols(bird2,2:end),delete,nsymbols);
                    
                else
                    tr_en{r_ind,theta_ind}(bird1,bird2)=0;
                    td_corr{r_ind,theta_ind}(bird1,bird2) = 0;
                    %tdmi{r_ind}(bird1,bird2)=0;
                    
                end
            end
        end
    end
end
end


