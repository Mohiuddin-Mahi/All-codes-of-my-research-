
clear all;clc;close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%In probabiity function we have used [1,2,3,4,5,6] symbols
%For different sequance of symbols, we need to change there
%Sequence should not contain any 0 symbol
%%%%%%%%%%%%%%%%%%%%%%%%%%
warning 'In probabiity function we have used [1,2,3,4,5,6] symbols'
warning 'For different sequance of symbols, we need to change there'
warning 'Sequence should not contain any 0 symbol'
r=3;
delay=1;
nbird=10;
num_leaders=1;
lbox=10;
vs=0.3;
dt=1;
nsymbols=6;
weight=1.05;%;

r_array=[linspace(0,5,21) (lbox/2)*sqrt(2)];
theta_array=[0 2*pi];
weight_factor=ones(nbird,nbird);
weight_factor(num_leaders+1:end,1:num_leaders)=weight;
noise_array=linspace(0,2*pi,21);
%noise_indx=[13,3,19];
TMAX=100000;

sight_angle=2*pi;
for noise_ind=1:length(noise_array)
    eta=noise_array(noise_ind);
    parfor trial_ind=1:1000
        tic
        
        [theta_out,~,~,delete_r,delete_theta]  =vicsek_April_2020_Udoy(lbox,vs,dt,r,eta,nbird,TMAX,weight_factor,sight_angle,r_array,theta_array);
        toc
        tic
        [tr_en,td_corr]=calc_te_function_theta_r_cutoff(nbird,theta_out,TMAX,delete_r,delete_theta,r_array,theta_array,nsymbols,delay);
        toc
        TE{trial_ind}{noise_ind,:}=tr_en;
        TDC{trial_ind}{noise_ind,:}=td_corr;
    end
    %save(['theta_r_cutoff_results_noise_',num2str(noise_indx(noise_ind)),'.mat'],'TE','TDC','-v7.3')
end

save(['check_theta_r_cutoff_results.mat'],'TE','TDC','-v7.3')


% clearvars -except va;
% va_w_angle=va;
% save('va_w_angle.mat','va_w_angle')
% figure;
% plot(noise_array,mean(va_w_angle))
% hold on
% plot(noise_array,mean(va_wo_angle))
% % legend('Mine','Sulimon')
% % ylim([0 1])
% % grid on
% v=VideoWriter('movie.avi');
% v.FrameRate=3;
% v.Quality=10;
% open(v)
% for tmax_ind=1:500
%     figure;
%     quiver(x_out(:,tmax_ind),y_out(:,tmax_ind),0.5*cos(theta_out(:,tmax_ind)),0.5*sin(theta_out(:,tmax_ind)),'r','linewidth',0.5,'AutoScale','off')
%         shg
%         for bird1=1%:nbird
%             curr_x=x_out(bird1,tmax_ind);
%             curr_y=y_out(bird1,tmax_ind);
%             curr_ang=theta_out(bird1,tmax_ind);
%
%             l_sight_range=curr_ang-(sight_angle/2);
%             r_sight_range=curr_ang+(sight_angle/2);
%             x=[];y=[];
%             x= r*cos(linspace(0,2*pi, 100))+curr_x;
%             y= r*sin(linspace(0,2*pi, 100))+curr_y;
%             for ind=1:length(x)
%                 if (x(ind)>lbox)
%                     x(ind)=x(ind)-lbox;
%                 end
%                 if (x(ind)<0)
%                     x(ind)=x(ind)+lbox;
%                 end
%
%                 if (y(ind)>lbox)
%                     y(ind)=y(ind)-lbox;
%                 end
%                 if (y(ind)<0)
%                     y(ind)=y(ind)+lbox;
%                 end
%             end
%             hold on
%             plot(x,y,'.')
%             hold on
%             x=[];y=[];
%             x= r*cos(linspace(min(l_sight_range,r_sight_range),max(l_sight_range,r_sight_range), 100))+curr_x;
%             y= r*sin(linspace(min(l_sight_range,r_sight_range),max(l_sight_range,r_sight_range), 100))+curr_y;
%     %
%     %
%     %         for ind=1:length(x)
%     %             if (x(ind)>lbox)
%     %                 x(ind)=x(ind)-lbox;
%     %             end
%     %             if (x(ind)<0)
%     %                 x(ind)=x(ind)+lbox;
%     %             end
%     %
%     %             if (y(ind)>lbox)
%     %                 y(ind)=y(ind)-lbox;
%     %             end
%     %             if (y(ind)<0)
%     %                 y(ind)=y(ind)+lbox;
%     %             end
%     %         end
%             hold on
%             plot([curr_x x curr_x],[curr_y y curr_y],'-r')
%             hold on
%             quiver(curr_x,curr_y,0.5*cos(curr_ang),0.5*sin(curr_ang),'b','linewidth',0.5,'AutoScale','off')
%             xlim ([0 lbox])
%             ylim ([0 lbox])
%
%         end
%     axis tight;
%     set(gcf,'Units','Normalized','outerPosition',[0 0 1 1]);
%     axis equal
%     set(gca,'xlim',[0 lbox])
%     set(gca,'ylim',[0 lbox])
%     title(['frame number: ',num2str(tmax_ind)])
%     shg
%     g=getframe(gcf);
%     writeVideo(v,g);
%     close all;
%
% end
% close(v);
%
