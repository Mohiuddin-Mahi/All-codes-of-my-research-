
function [theta_out,x_out,y_out] = vicsek_April_2020_Udoy(lbox,vs,dt,r,eta,nbird,TMAX,wmat)

vx=zeros(nbird,TMAX);% initialling v_X
vy=zeros(nbird,TMAX);% initialling v_Y

xb=rand(nbird,1).*lbox; % random x-coordinates of birds
yb=rand(nbird,1).*lbox;% random y-coordinates of birds

ang=pi.*2.*rand(nbird,1); %randon angles (theta) of birds
nsteps=1;
vxb=vs.*cos(ang);%v_x=v*cos (theta)
vyb=vs.*sin(ang);%v_y=v*sin (theta)
vx(:,nsteps)=vxb; %store v_x in the array.
vy(:,nsteps)=vyb; %store v_y in the array.



theta_out(:,1)=ang;%store theta in the array.
theta=ang;
x_out(:,1)=xb;
y_out(:,1)=yb;

delete_inds_r=zeros(TMAX,nbird,nbird,'uint8');
delete_inds_theta=zeros(TMAX,nbird,nbird,'uint8');


for nsteps=2:TMAX
    x_prev=xb; % x-coordinate at time (nsteps-1)
    y_prev=yb; % y-coordinate at time (nsteps-1)
    xb=xb+vxb.*dt; % updated x-coordinate
    yb=yb+vyb.*dt; % updated y-coordinate
    
    for bird1=1:nbird
        
        [xb,yb]=boundary_conditions(xb,yb,bird1,lbox); % keep the location with the box.
        
        all_x=x_prev(1:nbird);
        all_y=y_prev(1:nbird);
        nearang=nearby_average_Udoy(all_x,all_y,bird1,r,lbox) ;% neighboring birds calculations
        %nearang=nearby_average_Udoy_sight_angle(all_x,all_y,ang,bird1,r,lbox,sight_angle);
        %nearang=nearby_average_Udoy_sight_angle_polar(all_x,all_y,ang,bird1,r,lbox,sight_angle);
        %[nearang,delete_ind_r,delete_ind_theta]=nearby_average_Udoy_sight_angle_polar_with_cutoff(all_x,all_y,ang,bird1,r,lbox,sight_angle,r_array,theta_array);
        
%         for d_ind=1:nbird
%             delete_inds_r(nsteps-1,bird1,d_ind)=delete_ind_r(d_ind);
%             delete_inds_theta(nsteps-1,bird1,d_ind)=delete_ind_theta(d_ind);
%         end
        [vxtemp,vytemp]=calc_nearby_average(wmat,nearang,bird1,vx(nearang,nsteps-1),vy(nearang,nsteps-1));% avg. of neighboring birds
        
        vtemp=[vxtemp,vytemp];
        curr_theta=calc_curr_theta(vxtemp,vytemp,vtemp);
        
        theta(bird1)=curr_theta;
        
        
        
    end
    ang=theta+eta.*(rand(nbird,1)-0.5)  ;% add noise to theta
    
    
    ang(ang>2*pi)=ang(ang>2*pi)-2*pi;% after adding noise keep theta from 0 to 2*pi
    ang(ang<0) = ang(ang<0) + 2*pi;% after adding noise keep theta from 0 to 2*pi
    
    vxb=vs.*cos(ang);%v_x=v*cos (theta)
    vyb=vs.*sin(ang);%v_x=v*cos (theta)
    vx(:,nsteps)=vxb;% save all v_x
    vy(:,nsteps)=vyb;% save all v_y
    
    theta_out(:,nsteps)=ang;% save all theta
    x_out(:,nsteps)=xb; % save all x coordinate
    y_out(:,nsteps)=yb;% save all y corrdinate
    
    
    
    
end
% clear v
% %%%% calc V_a%%%%
% v=sqrt(vx(:,end).^2+vy(:,end).^2);
% v_x1=vx(:,end)./v;
% v_y1=vy(:,end)./v;
% vx2=sum(v_x1);%/nbird;
% vy2=sum(v_y1);%/nbird;
% va=sqrt(vx2.^2+vy2.^2);
% va=va/nbird;

% vx1=vx(:,end).^2;
% vy1=vy(:,end).^2;
% d=vx1+vy1;
% d=sqrt(d);
% %vx2 is velocity unitization
% vx2=vx(:,end)./d;
% vy2=vy(:,end)./d;
% %Calculate the degree of polarization
% vx3=sum(vx2)/nbird;
% vy3=sum(vy2)/nbird;
% %p is degree of polarization
% p=sqrt(vx3.^2+vy3.^2);
% va=p;
end

function [xb,yb]=boundary_conditions(xb,yb,bird1,lbox)

if(xb(bird1)<0);xb(bird1)=xb(bird1)+lbox; end
if (yb(bird1)<0);yb(bird1)=yb(bird1)+lbox;end
if (xb(bird1)>lbox);xb(bird1)=xb(bird1)-lbox;end
if (yb(bird1)>lbox);yb(bird1)=yb(bird1)-lbox;end

end

% function [nearang,delete_mat]=calc_delete_inds_and_nearby(all_x,all_y,bird1,lbox,r,r_array,nbird)
% [nearang,delete_mat]=mex_hyp_with_r(all_x,all_y,bird1,lbox,r,r_array,length(r_array));
% delete_mat=reshape(delete_mat,length(r_array),nbird);
% nearang=find(nearang);
% end

function [vxtemp,vytemp]=calc_nearby_average(wmat,nearang,bird1,curr_vx_nearby,curr_vy_nearby)
curr_weights=wmat(bird1,:);
weights0=curr_weights(nearang)';
weights=weights0;
vxtemp=(sum(weights.*curr_vx_nearby,1))./(sum(weights,1));
vytemp=(sum(weights.*curr_vy_nearby,1))./(sum(weights,1));
end


function curr_theta=calc_curr_theta(vxtemp,vytemp,vtemp)
if vytemp>=0
    curr_theta=acos(vxtemp/norm(vtemp));
else
    if vytemp<0
        curr_theta=2*pi-acos(vxtemp/norm(vtemp));
        
    end
end
end


