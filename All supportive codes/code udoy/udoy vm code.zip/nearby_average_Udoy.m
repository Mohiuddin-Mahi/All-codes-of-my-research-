
function [nearby_birds]=nearby_average_Udoy(all_x,all_y,bird1,r,lbox)

curr_x=all_x(bird1);
curr_y=all_y(bird1);

diff_x1=abs(curr_x-all_x);
diff_y1=abs(curr_y-all_y);

min_diff_x=min(diff_x1,lbox-diff_x1);
min_diff_y=min(diff_y1,lbox-diff_y1);

dis=sqrt(min_diff_x.^2+min_diff_y.^2);

nearby_birds=find(dis<=r);
end