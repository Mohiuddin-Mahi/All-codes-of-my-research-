
function [nearby_birds,delete_ind_r,delete_ind_theta]=nearby_average_Udoy_sight_angle_polar_with_cutoff(all_x,all_y,ang,bird1,r,lbox,sight_angle,r_array,theta_array)

curr_x=all_x(bird1);
curr_y=all_y(bird1);

diff_x1=abs(curr_x-all_x);
diff_y1=abs(curr_y-all_y);

min_diff_x=min(diff_x1,lbox-diff_x1);
min_diff_y=min(diff_y1,lbox-diff_y1);

dis=sqrt(min_diff_x.^2+min_diff_y.^2);

nearby_birds_1=find(dis<=r);
delete_ind_r=zeros(1,length(all_x));
for ind=1:length(all_x)
    delete_ind_r(ind)=find (r_array>=dis(ind),1);
end
curr_ang=ang(bird1);
%%%%%%%%%%%%%%%%%%%%%Sight angle%%%%%%%%%%%%%%%%%%%%%%%%%%


for ind=1:length(all_x)
    if(ind~=bird1)
        nbd_x=all_x(ind);
        nbd_y=all_y(ind);
       
        if (nbd_x <= r && curr_x>=lbox-r)
            nbd_x=nbd_x+lbox;
        elseif (nbd_x>=lbox-r && curr_x<=r)
            nbd_x=nbd_x-lbox;
        end
        
        if (nbd_y <= r && curr_y>=lbox-r)
            nbd_y=nbd_y+lbox;
        elseif (nbd_y>=lbox-r && curr_y<=r)
            nbd_y=nbd_y-lbox;
        end
        
            vec=[];vec_1=[];
            vec=[nbd_x-curr_x  nbd_y-curr_y ];
            vec1=[r*cos(ang(bird1)) r*sin(ang(bird1))];
            dotV=vec(1)*vec1(1)+vec(2)*vec1(2);
            ang_diff(ind)=acos(dotV/(norm(vec)*r));
    else
        ang_diff(ind)=0;
    end
end


nearby_birds=intersect(find(dis<=r) , find(ang_diff<=(sight_angle/2)));
delete_ind_theta=zeros(1,length(all_x));
for ind=1:length(all_x)
    a=[];
    a=find ((theta_array./2)>=ang_diff(ind),1);
    if(~isempty(a))
        delete_ind_theta(ind)=a;
    end
end
% figure;
% quiver(all_x,all_y,0.5*cos(ang),0.5*sin(ang),'r','linewidth',0.5,'AutoScale','off')
% hold on
% quiver(all_x(1),all_y(1),0.5*cos(ang(1)),0.5*sin(ang(1)),'b','linewidth',0.5,'AutoScale','off')
% hold on
% quiver(all_x(nearby_birds),all_y(nearby_birds),0.5*cos(ang(nearby_birds)),0.5*sin(ang(nearby_birds)),'g','linewidth',0.5,'AutoScale','off')
% l_sight_range=curr_ang-(sight_angle/2);
% r_sight_range=curr_ang+(sight_angle/2);
% x=[];y=[];
% x= r*cos(linspace(0,2*pi, 100))+curr_x;
% y= r*sin(linspace(0,2*pi, 100))+curr_y;
% hold on
% plot(x,y,'.')
% hold on
% x=[];y=[];
% x= r*cos(linspace(min(l_sight_range,r_sight_range),max(l_sight_range,r_sight_range), 100))+curr_x;
% y= r*sin(linspace(min(l_sight_range,r_sight_range),max(l_sight_range,r_sight_range), 100))+curr_y;
% hold on
% plot([curr_x x curr_x],[curr_y y curr_y],'-r')

end

