clear all;clc
load('theta_r_cutoff_results_noise_19.mat')
nbird=10;
num_trial=1000;
lbox=10;
r_array=[linspace(0,5,16) (lbox/2)*sqrt(2)];
theta_array=linspace(0,2*pi,15);
noise_array=linspace(0,2*pi,21);

for trial_ind=1:num_trial
    for noise_ind=1
        for theta_ind=1:length(theta_array)
            for r_ind=1:length(r_array)
                A1=[];A2=[];
                A1=TE{trial_ind}{noise_ind}{r_ind,theta_ind};
                A2=TDC{trial_ind}{noise_ind}{r_ind,theta_ind};
                
                C1=A1-A1';
                C2=A2-A2';
                
                net_te{theta_ind,r_ind}(trial_ind,:)=sum(C1,2)/(nbird-1);
                net_tdc{theta_ind,r_ind}(trial_ind,:)=sum(C2,2)/(nbird-1);
                
            end
        end
    end
end

for theta_ind=1:length(theta_array)
    
    parfor r_ind=1:length(r_array)
        tic
        [~,~,A1]=ROC_curve_analysis(net_te{theta_ind,r_ind});
        [~,~,A2]=ROC_curve_analysis(net_tdc{theta_ind,r_ind});
        toc
        AUC_te(theta_ind,r_ind)=A1;
        AUC_tdc(theta_ind,r_ind)=A2;
        
    end
end
save(['AUC_noise_19.mat'],'AUC_te','AUC_tdc')


figure;
heatmap(r_array(2:end),theta_array(2:end),AUC_te(2:end,2:end))
colormap(jet)
caxis([0.5 1])
xlabel('Cutoff distance \lambda')
ylabel('Cutoff angle \beta')
title('R=3; angle of view=\pi')
