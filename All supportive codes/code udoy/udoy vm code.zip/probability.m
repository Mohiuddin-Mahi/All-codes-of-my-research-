
function pr_x=probability(x)

[freq,values]=hist(double(x),[1 2 3 4 5 6]);
pr_x = freq./sum(freq);
end